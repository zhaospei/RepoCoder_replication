fn main() {}
/*
fib 20                  time:   [11.483 µs 11.488 µs 11.493 µs]
Found 11 outliers among 100 measurements (11.00%)
  1 (1.00%) low severe
  2 (2.00%) low mild
  7 (7.00%) high mild
  1 (1.00%) high severe

*/
