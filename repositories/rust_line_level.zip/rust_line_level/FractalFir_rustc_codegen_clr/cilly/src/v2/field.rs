use serde::{Deserialize, Serialize};

use super::bimap::BiMapIndex;
use super::{bimap::IntoBiMapIndex, ClassRefIdx, StringIdx, Type};
use crate::field_desc::FieldDescriptor as V1Field;
use crate::static_field_desc::StaticFieldDescriptor as V1StaticField;

#[derive(Hash, PartialEq, Eq, Clone, Debug, Copy, Serialize, Deserialize)]
pub struct FieldIdx(BiMapIndex);
impl IntoBiMapIndex for FieldIdx {
    fn from_index(val: BiMapIndex) -> Self {
        Self(val)
    }
    fn as_bimap_index(&self) -> BiMapIndex {
        self.0
    }
}
#[derive(Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Debug)]
pub struct FieldDesc {
    owner: ClassRefIdx,
    name: StringIdx,
    tpe: Type,
}

impl FieldDesc {
    #[must_use]
    pub fn new(owner: ClassRefIdx, name: StringIdx, tpe: Type) -> Self {
        Self { owner, name, tpe }
    }

    pub(crate) fn from_v1(desc: &V1Field, asm: &mut super::Assembly) -> Self {
        let owner = desc.owner();

        Self::new(*owner, asm.alloc_string(desc.name()), *desc.tpe())
    }

    #[must_use]
    pub fn owner(&self) -> ClassRefIdx {
        self.owner
    }

    #[must_use]
    pub fn name(&self) -> StringIdx {
        self.name
    }

    #[must_use]
    pub fn tpe(&self) -> Type {
        self.tpe
    }
}
#[derive(Hash, PartialEq, Eq, Clone, Debug, Copy, Serialize, Deserialize)]
pub struct StaticFieldIdx(BiMapIndex);
impl IntoBiMapIndex for StaticFieldIdx {
    fn from_index(val: BiMapIndex) -> Self {
        Self(val)
    }
    fn as_bimap_index(&self) -> BiMapIndex {
        self.0
    }
}
#[derive(Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize, Debug)]
pub struct StaticFieldDesc {
    owner: ClassRefIdx,
    name: StringIdx,
    tpe: Type,
}

impl StaticFieldDesc {
    #[must_use]
    pub fn new(owner: ClassRefIdx, name: StringIdx, tpe: Type) -> Self {
        Self { owner, name, tpe }
    }

    pub fn from_v1(desc: &V1StaticField, asm: &mut super::Assembly) -> Self {
        let owner = if let Some(owner) = desc.owner() {
            *owner
        } else {
            *asm.main_module()
        };
        Self::new(owner, asm.alloc_string(desc.name()), *desc.tpe())
    }

    #[must_use]
    pub fn owner(&self) -> ClassRefIdx {
        self.owner
    }

    #[must_use]
    pub fn name(&self) -> StringIdx {
        self.name
    }

    #[must_use]
    pub fn tpe(&self) -> Type {
        self.tpe
    }
}
