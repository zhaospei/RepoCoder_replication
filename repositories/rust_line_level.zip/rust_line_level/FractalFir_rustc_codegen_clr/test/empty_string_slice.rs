pub fn main(){
    let slice = "";
    std::hint::black_box(slice);
}
