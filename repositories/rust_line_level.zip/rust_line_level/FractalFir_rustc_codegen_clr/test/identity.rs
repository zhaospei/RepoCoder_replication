#[no_mangle]
pub extern fn identity(a:i32)->i32{a}
