pub extern fn sqrt(input:f32)->f32{
    input.sqrt()
}
